var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
const __vite_import_meta_env__$1 = { "BASE_URL": "/", "DEV": false, "MODE": "production", "PROD": true, "SSR": false };
class RequestManager {
  constructor() {
    __publicField(this, "pendingRequests", /* @__PURE__ */ new Map());
    // 去重Map
    __publicField(this, "batchQueue", /* @__PURE__ */ new Map());
    // 批量队列
    __publicField(this, "contextGroups", /* @__PURE__ */ new Map());
    // 上下文分组
    __publicField(this, "executingRequests", /* @__PURE__ */ new Set());
    // 执行中的请求
    __publicField(this, "BATCH_SIZE", 5);
    // 批量大小
    __publicField(this, "BATCH_DELAY", 100);
    // 批量延迟(ms)
    __publicField(this, "DEDUP_TTL", 3e4);
    // 去重TTL(ms)
    __publicField(this, "CONTEXT_TTL", 6e4);
    // 上下文TTL(ms)
    __publicField(this, "MAX_RETRIES", 3);
  }
  // 最大重试次数
  /**
   * 添加翻译请求（自动去重和批量处理）
   */
  async addRequest(request) {
    return new Promise((resolve, reject) => {
      const requestKey = this.generateRequestKey(request);
      const batchRequest = {
        ...request,
        resolve,
        reject,
        timestamp: Date.now(),
        priority: request.priority || 1
      };
      const duplicate = this.checkDuplicate(requestKey);
      if (duplicate) {
        duplicate.push(batchRequest);
        return;
      }
      this.pendingRequests.set(requestKey, [batchRequest]);
      this.addToBatch(batchRequest);
      if (request.context) {
        this.addToContextGroup(batchRequest);
      }
    });
  }
  /**
   * 生成请求唯一键
   */
  generateRequestKey(request) {
    return `${request.text}|${request.source}|${request.target}|${request.format || "text"}`;
  }
  /**
   * 检查重复请求
   */
  checkDuplicate(requestKey) {
    const existing = this.pendingRequests.get(requestKey);
    if (existing && existing.length > 0) {
      const firstRequest = existing[0];
      if (Date.now() - firstRequest.timestamp < this.DEDUP_TTL) {
        return existing;
      } else {
        this.pendingRequests.delete(requestKey);
      }
    }
    return null;
  }
  /**
   * 添加到批量队列
   */
  addToBatch(request) {
    const batchKey = `${request.source}|${request.target}`;
    if (!this.batchQueue.has(batchKey)) {
      this.batchQueue.set(batchKey, {
        requests: [],
        timer: 0,
        executing: false
      });
    }
    const batch = this.batchQueue.get(batchKey);
    batch.requests.push(request);
    if (batch.timer) {
      clearTimeout(batch.timer);
    }
    if (batch.requests.length >= this.BATCH_SIZE) {
      this.executeBatch(batchKey);
    } else {
      batch.timer = window.setTimeout(() => {
        this.executeBatch(batchKey);
      }, this.BATCH_DELAY);
    }
  }
  /**
   * 添加到上下文分组
   */
  addToContextGroup(request) {
    if (!request.context) return;
    const context = request.context;
    if (!this.contextGroups.has(context)) {
      this.contextGroups.set(context, {
        context,
        requests: [],
        lastActivity: Date.now()
      });
    }
    const group = this.contextGroups.get(context);
    group.requests.push(request);
    group.lastActivity = Date.now();
    this.cleanupContextGroups();
  }
  /**
   * 执行批量请求
   */
  async executeBatch(batchKey) {
    const batch = this.batchQueue.get(batchKey);
    if (!batch || batch.executing || batch.requests.length === 0) {
      return;
    }
    batch.executing = true;
    clearTimeout(batch.timer);
    try {
      const requests = batch.requests.splice(0, this.BATCH_SIZE);
      requests.sort((a, b) => (b.priority || 1) - (a.priority || 1));
      const batchRequest = this.buildBatchRequest(requests);
      const results = await this.sendBatchRequest(batchRequest);
      this.handleBatchResults(requests, results);
    } catch (error) {
      this.handleBatchError(batch.requests, error);
    } finally {
      batch.executing = false;
      if (batch.requests.length > 0) {
        this.addToBatch(batch.requests[0]);
      } else {
        this.batchQueue.delete(batchKey);
      }
    }
  }
  /**
   * 构建批量请求
   */
  buildBatchRequest(requests) {
    const [firstRequest] = requests;
    return {
      target: firstRequest.target,
      segments: requests.map((req) => ({
        id: req.id,
        text: req.text,
        model: "qwen-turbo-latest"
      })),
      extra_args: {
        batch_size: requests.length,
        context_aware: this.hasContextualRequests(requests)
      }
    };
  }
  /**
   * 检查是否有上下文相关请求
   */
  hasContextualRequests(requests) {
    return requests.some((req) => req.context);
  }
  /**
   * 发送批量请求（带智能重试）
   */
  async sendBatchRequest(batchRequest, retryCount = 0) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1e4);
    try {
      const backendUrl = __vite_import_meta_env__$1?.BACKEND_URL || "http://localhost:8000";
      const response = await fetch(`${backendUrl}/translate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(batchRequest),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      if (retryCount < this.MAX_RETRIES) {
        const delay = Math.min(1e3 * Math.pow(2, retryCount), 5e3);
        await new Promise((resolve) => setTimeout(resolve, delay));
        return this.sendBatchRequest(batchRequest, retryCount + 1);
      }
      throw error;
    }
  }
  /**
   * 处理批量结果
   */
  handleBatchResults(requests, results) {
    const segments = results.segments || [];
    requests.forEach((request) => {
      const requestKey = this.generateRequestKey(request);
      const duplicates = this.pendingRequests.get(requestKey) || [request];
      const segment = segments.find((s) => s.id === request.id);
      if (segment) {
        const result = {
          ok: true,
          data: {
            translatedText: segment.text,
            detectedLanguage: results.translated,
            alternatives: segment.alternatives || []
          }
        };
        duplicates.forEach((dup) => dup.resolve(result));
      } else {
        const error = {
          ok: false,
          error: {
            code: "SEGMENT_NOT_FOUND",
            message: "未找到对应的翻译结果"
          }
        };
        duplicates.forEach((dup) => dup.reject(error));
      }
      this.pendingRequests.delete(requestKey);
    });
  }
  /**
   * 处理批量错误
   */
  handleBatchError(requests, error) {
    requests.forEach((request) => {
      const requestKey = this.generateRequestKey(request);
      const duplicates = this.pendingRequests.get(requestKey) || [request];
      const errorResult = {
        ok: false,
        error: {
          code: "BATCH_REQUEST_FAILED",
          message: error.message || "批量请求失败"
        }
      };
      duplicates.forEach((dup) => dup.reject(errorResult));
      this.pendingRequests.delete(requestKey);
    });
  }
  /**
   * 清理过期的上下文组
   */
  cleanupContextGroups() {
    const now = Date.now();
    for (const [context, group] of this.contextGroups.entries()) {
      if (now - group.lastActivity > this.CONTEXT_TTL) {
        this.contextGroups.delete(context);
      }
    }
  }
  /**
   * 获取上下文相关的翻译历史
   */
  getContextHistory(context) {
    const group = this.contextGroups.get(context);
    return group ? group.requests.slice() : [];
  }
  /**
   * 获取统计信息
   */
  getStats() {
    return {
      pendingRequests: this.pendingRequests.size,
      batchQueues: this.batchQueue.size,
      contextGroups: this.contextGroups.size,
      executingRequests: this.executingRequests.size
    };
  }
}
const requestManager = new RequestManager();
class OfflineTranslationManager {
  constructor() {
    __publicField(this, "providers", []);
    __publicField(this, "dictionaries", /* @__PURE__ */ new Map());
    // 语言对字典
    __publicField(this, "rules", []);
    // 翻译规则
    __publicField(this, "patterns", /* @__PURE__ */ new Map());
    // 语言模式
    __publicField(this, "initialized", false);
  }
  /**
   * 初始化离线翻译系统
   */
  async initialize() {
    if (this.initialized) return;
    await this.initializeProviders();
    await this.loadDictionaries();
    await this.loadTranslationRules();
    await this.loadLanguagePatterns();
    this.initialized = true;
    console.log("Offline translation system initialized");
  }
  /**
   * 初始化翻译提供器
   */
  async initializeProviders() {
    this.providers.push({
      name: "dictionary",
      priority: 3,
      available: true,
      translate: this.dictionaryTranslate.bind(this)
    });
    this.providers.push({
      name: "rules",
      priority: 2,
      available: true,
      translate: this.ruleBasedTranslate.bind(this)
    });
    this.providers.push({
      name: "pattern",
      priority: 1,
      available: true,
      translate: this.patternTranslate.bind(this)
    });
    if (typeof Worker !== "undefined") {
      this.providers.push({
        name: "ml-worker",
        priority: 4,
        available: false,
        // 需要模型文件
        translate: this.mlTranslate.bind(this),
        detect: this.mlDetect.bind(this)
      });
    }
    this.providers.sort((a, b) => b.priority - a.priority);
  }
  /**
   * 加载本地字典
   */
  async loadDictionaries() {
    const enZhDict = {
      "hello": { "zh": "你好" },
      "world": { "zh": "世界" },
      "computer": { "zh": "计算机" },
      "internet": { "zh": "互联网" },
      "software": { "zh": "软件" },
      "hardware": { "zh": "硬件" },
      "technology": { "zh": "技术" },
      "artificial intelligence": { "zh": "人工智能" },
      "machine learning": { "zh": "机器学习" },
      "deep learning": { "zh": "深度学习" },
      "neural network": { "zh": "神经网络" },
      "database": { "zh": "数据库" },
      "algorithm": { "zh": "算法" },
      "programming": { "zh": "编程" },
      "development": { "zh": "开发" },
      "application": { "zh": "应用" },
      "system": { "zh": "系统" },
      "network": { "zh": "网络" },
      "security": { "zh": "安全" },
      "encryption": { "zh": "加密" },
      "authentication": { "zh": "认证" },
      "authorization": { "zh": "授权" },
      "cloud computing": { "zh": "云计算" },
      "big data": { "zh": "大数据" },
      "blockchain": { "zh": "区块链" },
      "cryptocurrency": { "zh": "加密货币" },
      "bitcoin": { "zh": "比特币" },
      "ethereum": { "zh": "以太坊" },
      "smart contract": { "zh": "智能合约" },
      "user interface": { "zh": "用户界面" },
      "user experience": { "zh": "用户体验" },
      "responsive design": { "zh": "响应式设计" },
      "mobile application": { "zh": "移动应用" },
      "web development": { "zh": "网站开发" },
      "frontend": { "zh": "前端" },
      "backend": { "zh": "后端" },
      "full stack": { "zh": "全栈" },
      "framework": { "zh": "框架" },
      "library": { "zh": "库" },
      "api": { "zh": "接口" },
      "rest api": { "zh": "REST接口" },
      "graphql": { "zh": "GraphQL" },
      "microservices": { "zh": "微服务" },
      "container": { "zh": "容器" },
      "docker": { "zh": "Docker" },
      "kubernetes": { "zh": "Kubernetes" },
      "devops": { "zh": "开发运维" },
      "continuous integration": { "zh": "持续集成" },
      "continuous deployment": { "zh": "持续部署" },
      "version control": { "zh": "版本控制" },
      "git": { "zh": "Git" },
      "github": { "zh": "GitHub" },
      "open source": { "zh": "开源" }
    };
    const zhEnDict = {
      "你好": { "en": "hello" },
      "世界": { "en": "world" },
      "计算机": { "en": "computer" },
      "人工智能": { "en": "artificial intelligence" },
      "机器学习": { "en": "machine learning" },
      "深度学习": { "en": "deep learning" },
      "神经网络": { "en": "neural network" },
      "数据库": { "en": "database" },
      "算法": { "en": "algorithm" },
      "编程": { "en": "programming" },
      "开发": { "en": "development" },
      "应用": { "en": "application" },
      "系统": { "en": "system" },
      "网络": { "en": "network" },
      "安全": { "en": "security" },
      "云计算": { "en": "cloud computing" },
      "大数据": { "en": "big data" },
      "区块链": { "en": "blockchain" },
      "用户界面": { "en": "user interface" },
      "用户体验": { "en": "user experience" },
      "响应式设计": { "en": "responsive design" },
      "前端": { "en": "frontend" },
      "后端": { "en": "backend" },
      "全栈": { "en": "full stack" },
      "框架": { "en": "framework" },
      "接口": { "en": "api" },
      "微服务": { "en": "microservices" },
      "容器": { "en": "container" },
      "开发运维": { "en": "devops" },
      "版本控制": { "en": "version control" },
      "开源": { "en": "open source" }
    };
    this.dictionaries.set("en-zh", enZhDict);
    this.dictionaries.set("zh-en", zhEnDict);
  }
  /**
   * 加载翻译规则
   */
  async loadTranslationRules() {
    this.rules = [
      // 英语复数规则
      {
        pattern: /(\w+)s$/i,
        replacement: "$1",
        languages: ["en"]
      },
      // 英语过去式规则
      {
        pattern: /(\w+)ed$/i,
        replacement: "$1",
        languages: ["en"]
      },
      // 英语进行时规则
      {
        pattern: /(\w+)ing$/i,
        replacement: "$1",
        languages: ["en"]
      },
      // URL 保持不变
      {
        pattern: /https?:\/\/[^\s]+/gi,
        replacement: "$&",
        languages: ["*"]
      },
      // 邮箱保持不变
      {
        pattern: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/gi,
        replacement: "$&",
        languages: ["*"]
      },
      // 数字保持不变
      {
        pattern: /\b\d+(\.\d+)?\b/g,
        replacement: "$&",
        languages: ["*"]
      }
    ];
  }
  /**
   * 加载语言检测模式
   */
  async loadLanguagePatterns() {
    this.patterns.set("zh", [
      /[\u4e00-\u9fff]/g,
      // 中文汉字
      /[\u3000-\u303f]/g
      // 中文标点
    ]);
    this.patterns.set("en", [
      /[a-zA-Z]/g,
      /\b(the|and|or|but|in|on|at|to|for|of|with|by)\b/gi
    ]);
    this.patterns.set("ja", [
      /[\u3040-\u309f]/g,
      // 平假名
      /[\u30a0-\u30ff]/g,
      // 片假名
      /[\u4e00-\u9fff]/g
      // 汉字
    ]);
    this.patterns.set("ko", [
      /[\uac00-\ud7af]/g,
      // 韩文字符
      /[\u1100-\u11ff]/g
      // 韩文字母
    ]);
  }
  /**
   * 离线翻译
   */
  async translate(text, source, target) {
    if (!this.initialized) {
      await this.initialize();
    }
    const availableProviders = this.providers.filter((p) => p.available);
    for (const provider of availableProviders) {
      try {
        const translated = await provider.translate(text, source, target);
        if (translated && translated !== text) {
          return {
            translated,
            confidence: this.calculateConfidence(text, translated, provider.name),
            provider: provider.name,
            fallback: true
          };
        }
      } catch (error) {
        console.warn(`Provider ${provider.name} failed:`, error);
        continue;
      }
    }
    return {
      translated: text,
      confidence: 0,
      provider: "none",
      fallback: true
    };
  }
  /**
   * 字典翻译
   */
  async dictionaryTranslate(text, source, target) {
    const dictKey = `${source}-${target}`;
    const dict = this.dictionaries.get(dictKey);
    if (!dict) {
      throw new Error(`Dictionary not found for ${dictKey}`);
    }
    const cleanText = text.toLowerCase().trim();
    if (dict[cleanText] && dict[cleanText][target]) {
      return dict[cleanText][target];
    }
    const words = cleanText.split(/\s+/);
    const translations = [];
    let hasTranslation = false;
    for (const word of words) {
      if (dict[word] && dict[word][target]) {
        translations.push(dict[word][target]);
        hasTranslation = true;
      } else {
        translations.push(word);
      }
    }
    if (hasTranslation) {
      return translations.join(" ");
    }
    throw new Error("No dictionary translation found");
  }
  /**
   * 规则翻译
   */
  async ruleBasedTranslate(text, source, _target) {
    let translatedText = text;
    for (const rule of this.rules) {
      if (rule.languages.includes("*") || rule.languages.includes(source)) {
        translatedText = translatedText.replace(rule.pattern, rule.replacement);
      }
    }
    if (translatedText !== text) {
      return translatedText;
    }
    throw new Error("No rule-based translation applied");
  }
  /**
   * 模式翻译
   */
  async patternTranslate(text, source, target) {
    const sourcePatterns = this.patterns.get(source);
    if (!sourcePatterns) {
      throw new Error(`No patterns found for source language: ${source}`);
    }
    let sourceCharCount = 0;
    for (const pattern of sourcePatterns) {
      const matches = text.match(pattern);
      if (matches) {
        sourceCharCount += matches.length;
      }
    }
    const density = sourceCharCount / text.length;
    if (density < 0.3) {
      throw new Error("Low source language character density");
    }
    if (source === "en" && target === "zh") {
      return text.replace(/\b(hello|hi)\b/gi, "你好").replace(/\bworld\b/gi, "世界").replace(/\bcomputer\b/gi, "计算机");
    }
    throw new Error("No pattern translation available");
  }
  /**
   * 机器学习翻译 (Web Workers)
   */
  async mlTranslate(_text, _source, _target) {
    throw new Error("ML translation not implemented yet");
  }
  /**
   * 机器学习语言检测
   */
  async mlDetect(_text) {
    throw new Error("ML detection not implemented yet");
  }
  /**
   * 检测语言
   */
  async detectLanguage(text) {
    if (!this.initialized) {
      await this.initialize();
    }
    let maxScore = 0;
    let detectedLang = "auto";
    for (const [lang, patterns] of this.patterns.entries()) {
      let score = 0;
      for (const pattern of patterns) {
        const matches = text.match(pattern);
        if (matches) {
          score += matches.length;
        }
      }
      const normalizedScore = score / text.length;
      if (normalizedScore > maxScore) {
        maxScore = normalizedScore;
        detectedLang = lang;
      }
    }
    return maxScore > 0.1 ? detectedLang : "auto";
  }
  /**
   * 计算翻译置信度
   */
  calculateConfidence(original, translated, provider) {
    if (original === translated) return 0;
    let confidence = 0.5;
    switch (provider) {
      case "dictionary":
        confidence = 0.9;
        break;
      case "rules":
        confidence = 0.6;
        break;
      case "pattern":
        confidence = 0.4;
        break;
      case "ml-worker":
        confidence = 0.8;
        break;
    }
    const lengthRatio = translated.length / original.length;
    if (lengthRatio < 0.5 || lengthRatio > 2) {
      confidence *= 0.8;
    }
    return Math.max(0, Math.min(1, confidence));
  }
  /**
   * 添加自定义字典条目
   */
  async addDictionaryEntry(source, target, sourceText, targetText) {
    const dictKey = `${source}-${target}`;
    if (!this.dictionaries.has(dictKey)) {
      this.dictionaries.set(dictKey, {});
    }
    const dict = this.dictionaries.get(dictKey);
    if (!dict[sourceText]) {
      dict[sourceText] = {};
    }
    dict[sourceText][target] = targetText;
    await this.saveDictionary(dictKey, dict);
  }
  /**
   * 保存字典到本地存储
   */
  async saveDictionary(dictKey, dict) {
    try {
      chrome.storage.local.set({
        [`offline_dict_${dictKey}`]: dict
      });
    } catch (error) {
      console.warn("Failed to save dictionary:", error);
    }
  }
  /**
   * 获取支持的离线语言对
   */
  getSupportedLanguagePairs() {
    return Array.from(this.dictionaries.keys());
  }
  /**
   * 获取统计信息
   */
  getStats() {
    return {
      providers: this.providers.length,
      availableProviders: this.providers.filter((p) => p.available).length,
      dictionaries: this.dictionaries.size,
      rules: this.rules.length,
      patterns: this.patterns.size,
      initialized: this.initialized
    };
  }
}
const offlineTranslationManager = new OfflineTranslationManager();
class PersonalTranslationMemory {
  constructor() {
    __publicField(this, "memoryDB", null);
    __publicField(this, "userPreferences", null);
    __publicField(this, "domainTemplates", /* @__PURE__ */ new Map());
    __publicField(this, "initialized", false);
    __publicField(this, "DB_NAME", "PersonalTranslationMemory");
    __publicField(this, "DB_VERSION", 1);
    __publicField(this, "MEMORY_STORE", "translations");
    __publicField(this, "PREFERENCES_STORE", "preferences");
    __publicField(this, "LEARNING_THRESHOLD", 0.7);
    // 学习阈值
    __publicField(this, "MAX_MEMORY_SIZE", 1e4);
  }
  // 最大记忆条目数
  /**
   * 初始化翻译记忆系统
   */
  async initialize() {
    if (this.initialized) return;
    await this.initializeDatabase();
    await this.loadUserPreferences();
    await this.initializeDomainTemplates();
    this.initialized = true;
    console.log("Personal Translation Memory initialized");
  }
  /**
   * 初始化数据库
   */
  async initializeDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.memoryDB = request.result;
        resolve();
      };
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.MEMORY_STORE)) {
          const memoryStore = db.createObjectStore(this.MEMORY_STORE, { keyPath: "id" });
          memoryStore.createIndex("sourceText", "sourceText", { unique: false });
          memoryStore.createIndex("targetText", "targetText", { unique: false });
          memoryStore.createIndex("languagePair", ["source", "target"], { unique: false });
          memoryStore.createIndex("domain", "domain", { unique: false });
          memoryStore.createIndex("lastUsed", "lastUsed", { unique: false });
          memoryStore.createIndex("confidence", "confidence", { unique: false });
        }
        if (!db.objectStoreNames.contains(this.PREFERENCES_STORE)) {
          db.createObjectStore(this.PREFERENCES_STORE, { keyPath: "userId" });
        }
      };
    });
  }
  /**
   * 加载用户偏好
   */
  async loadUserPreferences() {
    const userId = await this.getUserId();
    return new Promise((resolve, reject) => {
      if (!this.memoryDB) {
        reject(new Error("Database not initialized"));
        return;
      }
      const transaction = this.memoryDB.transaction([this.PREFERENCES_STORE], "readonly");
      const store = transaction.objectStore(this.PREFERENCES_STORE);
      const request = store.get(userId);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        if (request.result) {
          this.userPreferences = request.result;
        } else {
          this.userPreferences = {
            userId,
            languagePairs: ["en-zh", "zh-en"],
            domains: ["general"],
            style: "casual",
            preferredModels: ["qwen-turbo-latest"],
            customTerms: /* @__PURE__ */ new Map(),
            learningEnabled: true,
            lastSync: Date.now()
          };
          this.saveUserPreferences();
        }
        resolve();
      };
    });
  }
  /**
   * 初始化领域模板
   */
  async initializeDomainTemplates() {
    this.domainTemplates.set("tech", {
      domain: "tech",
      patterns: [
        "API",
        "SDK",
        "framework",
        "library",
        "database",
        "algorithm",
        "programming",
        "software",
        "hardware",
        "cloud computing",
        "artificial intelligence"
      ],
      terminology: /* @__PURE__ */ new Map([
        ["API", "API接口"],
        ["SDK", "软件开发套件"],
        ["framework", "框架"],
        ["library", "库"],
        ["database", "数据库"],
        ["algorithm", "算法"],
        ["programming", "编程"],
        ["software", "软件"],
        ["hardware", "硬件"],
        ["cloud computing", "云计算"],
        ["artificial intelligence", "人工智能"]
      ]),
      style: "technical"
    });
    this.domainTemplates.set("business", {
      domain: "business",
      patterns: [
        "meeting",
        "proposal",
        "contract",
        "revenue",
        "profit",
        "investment",
        "market",
        "strategy",
        "management",
        "leadership"
      ],
      terminology: /* @__PURE__ */ new Map([
        ["meeting", "会议"],
        ["proposal", "提案"],
        ["contract", "合同"],
        ["revenue", "营收"],
        ["profit", "利润"],
        ["investment", "投资"],
        ["market", "市场"],
        ["strategy", "战略"],
        ["management", "管理"],
        ["leadership", "领导力"]
      ]),
      style: "formal"
    });
    this.domainTemplates.set("academic", {
      domain: "academic",
      patterns: [
        "research",
        "methodology",
        "hypothesis",
        "experiment",
        "analysis",
        "conclusion",
        "literature",
        "theory",
        "empirical",
        "statistical"
      ],
      terminology: /* @__PURE__ */ new Map([
        ["research", "研究"],
        ["methodology", "方法论"],
        ["hypothesis", "假设"],
        ["experiment", "实验"],
        ["analysis", "分析"],
        ["conclusion", "结论"],
        ["literature", "文献"],
        ["theory", "理论"],
        ["empirical", "实证的"],
        ["statistical", "统计的"]
      ]),
      style: "formal"
    });
  }
  /**
   * 添加翻译记忆
   */
  async addMemory(sourceText, targetText, source, target, context) {
    if (!this.memoryDB) {
      throw new Error("Database not initialized");
    }
    const domain = await this.detectDomain(sourceText);
    const id = await this.generateId(sourceText, source, target);
    const entry = {
      id,
      source,
      target,
      sourceText: sourceText.trim(),
      targetText: targetText.trim(),
      createdAt: Date.now(),
      lastUsed: Date.now(),
      useCount: 1,
      confidence: 1,
      context,
      domain,
      tags: await this.extractTags(sourceText, targetText)
    };
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.MEMORY_STORE], "readwrite");
      const store = transaction.objectStore(this.MEMORY_STORE);
      const getRequest = store.get(id);
      getRequest.onsuccess = () => {
        if (getRequest.result) {
          const existing = getRequest.result;
          existing.useCount++;
          existing.lastUsed = Date.now();
          existing.confidence = Math.min(1, existing.confidence + 0.1);
          store.put(existing);
        } else {
          store.add(entry);
        }
        resolve(id);
      };
      getRequest.onerror = () => reject(getRequest.error);
    });
  }
  /**
   * 搜索翻译记忆
   */
  async searchMemory(sourceText, source, target, options = {}) {
    if (!this.memoryDB) return [];
    const {
      fuzzy = true,
      contextWeight = 0.3,
      domainFilter,
      minConfidence = 0.5,
      limit = 10
    } = options;
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.MEMORY_STORE], "readonly");
      const store = transaction.objectStore(this.MEMORY_STORE);
      const index = store.index("languagePair");
      const request = index.getAll([source, target]);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        let results = request.result;
        results = results.filter((entry) => entry.confidence >= minConfidence);
        if (domainFilter) {
          results = results.filter((entry) => entry.domain === domainFilter);
        }
        const scoredResults = results.map((entry) => ({
          entry,
          score: this.calculateSimilarity(sourceText, entry.sourceText, fuzzy, contextWeight)
        }));
        scoredResults.sort((a, b) => b.score - a.score);
        const finalResults = scoredResults.filter((item) => item.score > 0.3).slice(0, limit).map((item) => item.entry);
        resolve(finalResults);
      };
    });
  }
  /**
   * 学习用户偏好
   */
  async learnFromFeedback(translationId, rating, userCorrection) {
    if (!this.userPreferences?.learningEnabled) return;
    if (!this.memoryDB) {
      throw new Error("Database not initialized");
    }
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.MEMORY_STORE], "readwrite");
      const store = transaction.objectStore(this.MEMORY_STORE);
      const request = store.get(translationId);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const entry = request.result;
        if (!entry) {
          reject(new Error("Translation memory entry not found"));
          return;
        }
        entry.userRating = rating;
        entry.confidence = this.adjustConfidence(entry.confidence, rating);
        if (userCorrection) {
          entry.targetText = userCorrection.trim();
          entry.confidence = Math.max(entry.confidence, 0.8);
        }
        this.updateUserPreferences(entry, rating);
        store.put(entry).onsuccess = () => resolve();
      };
    });
  }
  /**
   * 获取个性化翻译建议
   */
  async getPersonalizedSuggestion(sourceText, source, target, context) {
    const memoryResults = await this.searchMemory(sourceText, source, target, {
      fuzzy: true,
      contextWeight: context ? 0.4 : 0.2,
      limit: 5
    });
    if (memoryResults.length > 0) {
      const bestMatch = memoryResults[0];
      return {
        suggestion: bestMatch.targetText,
        confidence: bestMatch.confidence,
        source: "memory",
        alternatives: memoryResults.slice(1, 4).map((entry) => entry.targetText)
      };
    }
    const preferenceBasedSuggestion = await this.generatePreferenceBasedSuggestion(
      sourceText,
      source,
      target
    );
    if (preferenceBasedSuggestion) {
      return preferenceBasedSuggestion;
    }
    const domainBasedSuggestion = await this.generateDomainBasedSuggestion(
      sourceText,
      source,
      target
    );
    return domainBasedSuggestion || {
      suggestion: sourceText,
      confidence: 0,
      source: "domain",
      alternatives: []
    };
  }
  /**
   * 检测文本领域
   */
  async detectDomain(text) {
    const lowerText = text.toLowerCase();
    let maxScore = 0;
    let detectedDomain = "general";
    for (const [domain, template] of this.domainTemplates.entries()) {
      let score = 0;
      for (const pattern of template.patterns) {
        if (lowerText.includes(pattern.toLowerCase())) {
          score++;
        }
      }
      const normalizedScore = score / template.patterns.length;
      if (normalizedScore > maxScore) {
        maxScore = normalizedScore;
        detectedDomain = domain;
      }
    }
    return maxScore > 0.2 ? detectedDomain : "general";
  }
  /**
   * 提取标签
   */
  async extractTags(sourceText, targetText) {
    const tags = /* @__PURE__ */ new Set();
    const words = [...sourceText.split(/\s+/), ...targetText.split(/\s+/)];
    words.forEach((word) => {
      const cleanWord = word.toLowerCase().replace(/[^\w]/g, "");
      if (cleanWord.length > 2) {
        tags.add(cleanWord);
      }
    });
    return Array.from(tags).slice(0, 10);
  }
  /**
   * 计算文本相似度
   */
  calculateSimilarity(text1, text2, fuzzy, contextWeight) {
    if (text1 === text2) return 1;
    let similarity = this.calculateLevenshteinSimilarity(text1, text2);
    if (fuzzy) {
      const words1 = new Set(text1.toLowerCase().split(/\s+/));
      const words2 = new Set(text2.toLowerCase().split(/\s+/));
      const intersection = new Set([...words1].filter((x) => words2.has(x)));
      const union = /* @__PURE__ */ new Set([...words1, ...words2]);
      const jaccardSimilarity = intersection.size / union.size;
      similarity = Math.max(similarity, jaccardSimilarity * 0.8);
    }
    similarity = similarity * (1 - contextWeight) + similarity * contextWeight;
    return similarity;
  }
  /**
   * 计算 Levenshtein 相似度
   */
  calculateLevenshteinSimilarity(str1, str2) {
    const len1 = str1.length;
    const len2 = str2.length;
    if (len1 === 0) return len2 === 0 ? 1 : 0;
    if (len2 === 0) return 0;
    const matrix = Array(len2 + 1).fill(null).map(() => Array(len1 + 1).fill(null));
    for (let i = 0; i <= len1; i++) {
      matrix[0][i] = i;
    }
    for (let j = 0; j <= len2; j++) {
      matrix[j][0] = j;
    }
    for (let j = 1; j <= len2; j++) {
      for (let i = 1; i <= len1; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          // deletion
          matrix[j - 1][i] + 1,
          // insertion
          matrix[j - 1][i - 1] + indicator
          // substitution
        );
      }
    }
    const maxLength = Math.max(len1, len2);
    return (maxLength - matrix[len2][len1]) / maxLength;
  }
  /**
   * 调整置信度
   */
  adjustConfidence(currentConfidence, rating) {
    const adjustment = (rating - 3) * 0.1;
    return Math.max(0, Math.min(1, currentConfidence + adjustment));
  }
  /**
   * 更新用户偏好
   */
  updateUserPreferences(entry, rating) {
    if (!this.userPreferences) return;
    if (entry.domain && rating >= 4) {
      if (!this.userPreferences.domains.includes(entry.domain)) {
        this.userPreferences.domains.push(entry.domain);
      }
    }
    if (rating >= 4 && entry.sourceText.split(" ").length <= 3) {
      this.userPreferences.customTerms.set(entry.sourceText, entry.targetText);
    }
    this.saveUserPreferences();
  }
  /**
   * 基于偏好生成建议
   */
  async generatePreferenceBasedSuggestion(sourceText, source, target) {
    if (!this.userPreferences) return null;
    const customTranslation = this.userPreferences.customTerms.get(sourceText);
    if (customTranslation) {
      return {
        suggestion: customTranslation,
        confidence: 0.9,
        source: "preference",
        alternatives: []
      };
    }
    return null;
  }
  /**
   * 基于领域生成建议
   */
  async generateDomainBasedSuggestion(sourceText, source, target) {
    const domain = await this.detectDomain(sourceText);
    const template = this.domainTemplates.get(domain);
    if (!template) return null;
    const domainTranslation = template.terminology.get(sourceText.toLowerCase());
    if (domainTranslation) {
      return {
        suggestion: domainTranslation,
        confidence: 0.8,
        source: "domain",
        alternatives: []
      };
    }
    return null;
  }
  /**
   * 生成ID
   */
  async generateId(text, source, target) {
    const data = `${text}|${source}|${target}`;
    const encoder = new TextEncoder();
    const hashBuffer = await crypto.subtle.digest("SHA-256", encoder.encode(data));
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  /**
   * 获取用户ID
   */
  async getUserId() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["userId"], (result) => {
        if (result.userId) {
          resolve(result.userId);
        } else {
          const userId = "user_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
          chrome.storage.local.set({ userId });
          resolve(userId);
        }
      });
    });
  }
  /**
   * 保存用户偏好
   */
  async saveUserPreferences() {
    if (!this.memoryDB || !this.userPreferences) return;
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.PREFERENCES_STORE], "readwrite");
      const store = transaction.objectStore(this.PREFERENCES_STORE);
      const preferencesToSave = {
        ...this.userPreferences,
        customTerms: Array.from(this.userPreferences.customTerms.entries()),
        lastSync: Date.now()
      };
      const request = store.put(preferencesToSave);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }
  /**
   * 清理过期记忆
   */
  async cleanupExpiredMemories() {
    if (!this.memoryDB) return 0;
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.MEMORY_STORE], "readwrite");
      const store = transaction.objectStore(this.MEMORY_STORE);
      const request = store.getAll();
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const entries = request.result;
        const cutoffTime = Date.now() - 365 * 24 * 60 * 60 * 1e3;
        let deletedCount = 0;
        entries.forEach((entry) => {
          if (entry.createdAt < cutoffTime && entry.useCount < 3) {
            store.delete(entry.id);
            deletedCount++;
          }
        });
        resolve(deletedCount);
      };
    });
  }
  /**
   * 导出翻译记忆
   */
  async exportMemory() {
    if (!this.memoryDB) throw new Error("Database not initialized");
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.MEMORY_STORE, this.PREFERENCES_STORE], "readonly");
      const memoryStore = transaction.objectStore(this.MEMORY_STORE);
      const preferencesStore = transaction.objectStore(this.PREFERENCES_STORE);
      const memoryRequest = memoryStore.getAll();
      const preferencesRequest = preferencesStore.getAll();
      Promise.all([
        new Promise((resolve2) => {
          memoryRequest.onsuccess = () => resolve2(memoryRequest.result);
        }),
        new Promise((resolve2) => {
          preferencesRequest.onsuccess = () => resolve2(preferencesRequest.result);
        })
      ]).then(([memories, preferences]) => {
        const exportData = {
          version: 1,
          exportDate: (/* @__PURE__ */ new Date()).toISOString(),
          memories,
          preferences
        };
        resolve(JSON.stringify(exportData, null, 2));
      }).catch(reject);
    });
  }
  /**
   * 获取统计信息
   */
  async getStats() {
    if (!this.memoryDB) return null;
    return new Promise((resolve, reject) => {
      const transaction = this.memoryDB.transaction([this.MEMORY_STORE], "readonly");
      const store = transaction.objectStore(this.MEMORY_STORE);
      const request = store.getAll();
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const entries = request.result;
        const stats = {
          totalEntries: entries.length,
          languagePairs: new Set(entries.map((e) => `${e.source}-${e.target}`)).size,
          domains: new Set(entries.map((e) => e.domain)).size,
          averageConfidence: entries.reduce((sum, e) => sum + e.confidence, 0) / entries.length,
          mostUsedEntry: entries.reduce((max, e) => e.useCount > max.useCount ? e : max, entries[0]),
          recentActivity: entries.filter((e) => e.lastUsed > Date.now() - 7 * 24 * 60 * 60 * 1e3).length
        };
        resolve(stats);
      };
    });
  }
}
const personalTranslationMemory = new PersonalTranslationMemory();
class ContextualTranslationEngine {
  constructor() {
    __publicField(this, "documentContexts", /* @__PURE__ */ new Map());
    __publicField(this, "contextPatterns", /* @__PURE__ */ new Map());
    __publicField(this, "terminologyExtractor");
    __publicField(this, "semanticAnalyzer");
    __publicField(this, "tonalAnalyzer");
    __publicField(this, "initialized", false);
    this.terminologyExtractor = new TerminologyExtractor();
    this.semanticAnalyzer = new SemanticAnalyzer();
    this.tonalAnalyzer = new TonalAnalyzer();
  }
  /**
   * 初始化上下文感知系统
   */
  async initialize() {
    if (this.initialized) return;
    await this.initializeContextPatterns();
    await this.terminologyExtractor.initialize();
    await this.semanticAnalyzer.initialize();
    await this.tonalAnalyzer.initialize();
    this.initialized = true;
    console.log("Contextual Translation Engine initialized");
  }
  /**
   * 初始化上下文模式
   */
  async initializeContextPatterns() {
    this.contextPatterns.set("pronouns", [
      /\b(this|that|these|those|it|they|them|their|its)\b/gi,
      /\b(这|那|它|他们|她们|它们|其|其中)\b/g
    ]);
    this.contextPatterns.set("temporal", [
      /\b(before|after|then|next|previously|subsequently|meanwhile|simultaneously)\b/gi,
      /\b(之前|之后|然后|接下来|先前|随后|同时|与此同时)\b/g
    ]);
    this.contextPatterns.set("causation", [
      /\b(because|since|therefore|thus|consequently|as a result|due to)\b/gi,
      /\b(因为|由于|所以|因此|结果|导致)\b/g
    ]);
    this.contextPatterns.set("contrast", [
      /\b(however|but|nevertheless|on the other hand|in contrast|whereas)\b/gi,
      /\b(然而|但是|不过|另一方面|相比之下|而)\b/g
    ]);
  }
  /**
   * 创建文档上下文
   */
  async createDocumentContext(documentId, sentences, metadata) {
    const contextualSentences = await this.analyzeSentences(sentences);
    const globalTerminology = await this.terminologyExtractor.extractGlobalTerminology(sentences);
    const documentTone = await this.tonalAnalyzer.analyzeTone(sentences.join(" "));
    const context = {
      id: documentId,
      title: metadata?.title,
      domain: metadata?.domain || await this.detectDomain(sentences),
      sentences: contextualSentences,
      globalTerminology,
      documentTone,
      createdAt: Date.now()
    };
    this.documentContexts.set(documentId, context);
    return context;
  }
  /**
   * 分析句子关系
   */
  async analyzeSentences(sentences) {
    const contextualSentences = [];
    for (let i = 0; i < sentences.length; i++) {
      const sentence = sentences[i];
      const id = `sentence_${i}`;
      const dependencies = await this.findDependencies(sentence, sentences, i);
      const semanticRelations = await this.semanticAnalyzer.analyzeRelations(
        sentence,
        sentences,
        i
      );
      contextualSentences.push({
        id,
        text: sentence,
        position: i,
        dependencies,
        semanticRelations
      });
    }
    return contextualSentences;
  }
  /**
   * 查找句子依赖关系
   */
  async findDependencies(sentence, allSentences, currentIndex) {
    const dependencies = [];
    const pronounPatterns = this.contextPatterns.get("pronouns") || [];
    let hasPronoun = false;
    for (const pattern of pronounPatterns) {
      if (pattern.test(sentence)) {
        hasPronoun = true;
        break;
      }
    }
    if (hasPronoun && currentIndex > 0) {
      const lookBack = Math.min(3, currentIndex);
      for (let i = currentIndex - lookBack; i < currentIndex; i++) {
        dependencies.push(`sentence_${i}`);
      }
    }
    const connectionPatterns = [
      ...this.contextPatterns.get("temporal") || [],
      ...this.contextPatterns.get("causation") || [],
      ...this.contextPatterns.get("contrast") || []
    ];
    for (const pattern of connectionPatterns) {
      if (pattern.test(sentence) && currentIndex > 0) {
        dependencies.push(`sentence_${currentIndex - 1}`);
        break;
      }
    }
    return dependencies;
  }
  /**
   * 上下文感知翻译
   */
  async translateWithContext(documentId, sentenceIndex, source, target, baseTranslation) {
    const context = this.documentContexts.get(documentId);
    if (!context) {
      throw new Error(`Document context not found: ${documentId}`);
    }
    const sentence = context.sentences[sentenceIndex];
    if (!sentence) {
      throw new Error(`Sentence not found: ${sentenceIndex}`);
    }
    let translatedText = baseTranslation || sentence.text;
    const adjustments = [];
    translatedText = await this.applyContextualAdjustments(
      sentence,
      context,
      translatedText,
      source,
      target,
      adjustments
    );
    const confidence = this.calculateContextualConfidence(sentence, context, adjustments);
    return {
      sentenceId: sentence.id,
      originalText: sentence.text,
      translatedText,
      confidence,
      contextualAdjustments: adjustments
    };
  }
  /**
   * 应用上下文调整
   */
  async applyContextualAdjustments(sentence, context, translation, source, target, adjustments) {
    let adjustedTranslation = translation;
    adjustedTranslation = await this.resolvePronounReferences(
      sentence,
      context,
      adjustedTranslation,
      source,
      target,
      adjustments
    );
    adjustedTranslation = await this.enforceTerminologyConsistency(
      context,
      adjustedTranslation,
      adjustments
    );
    adjustedTranslation = await this.adjustTone(
      context,
      adjustedTranslation,
      source,
      target,
      adjustments
    );
    adjustedTranslation = await this.adjustTense(
      sentence,
      context,
      adjustedTranslation,
      source,
      target,
      adjustments
    );
    adjustedTranslation = await this.applyCulturalAdjustments(
      adjustedTranslation,
      source,
      target,
      context.domain,
      adjustments
    );
    return adjustedTranslation;
  }
  /**
   * 代词引用消歧
   */
  async resolvePronounReferences(sentence, context, translation, source, target, adjustments) {
    if (sentence.dependencies.length === 0) return translation;
    let adjustedTranslation = translation;
    for (const depId of sentence.dependencies) {
      const depSentence = context.sentences.find((s) => s.id === depId);
      if (!depSentence) continue;
      const referents = await this.extractReferents(depSentence.text, source);
      if (source === "en" && target === "zh") {
        adjustedTranslation = this.replaceEnglishPronouns(
          adjustedTranslation,
          referents,
          adjustments
        );
      } else if (source === "zh" && target === "en") {
        adjustedTranslation = this.replaceChinesePronouns(
          adjustedTranslation,
          referents,
          adjustments
        );
      }
    }
    return adjustedTranslation;
  }
  /**
   * 提取指代对象
   */
  async extractReferents(text, language) {
    const referents = [];
    if (language === "en") {
      const subjectPattern = /^([A-Z][a-zA-Z\s]*?)(?:\s+(?:is|are|was|were|has|have|will|can|could|should|would))/;
      const match = text.match(subjectPattern);
      if (match) {
        referents.push(match[1].trim());
      }
    } else if (language === "zh") {
      const subjectPattern = /^([^，。！？；]*?)(?:是|在|有|会|能|应该|将要)/;
      const match = text.match(subjectPattern);
      if (match) {
        referents.push(match[1].trim());
      }
    }
    return referents;
  }
  /**
   * 替换英语代词
   */
  replaceEnglishPronouns(translation, referents, adjustments) {
    if (referents.length === 0) return translation;
    let adjusted = translation;
    const primaryReferent = referents[0];
    const pronounReplacements = [
      { pattern: /\b它\b/g, replacement: primaryReferent },
      { pattern: /\b这个\b/g, replacement: `这个${primaryReferent}` },
      { pattern: /\b那个\b/g, replacement: `那个${primaryReferent}` }
    ];
    pronounReplacements.forEach(({ pattern, replacement }) => {
      if (pattern.test(adjusted)) {
        const original = adjusted;
        adjusted = adjusted.replace(pattern, replacement);
        if (original !== adjusted) {
          adjustments.push({
            type: "pronoun",
            original: pattern.toString(),
            adjusted: replacement,
            reason: `代词消歧，指代对象：${primaryReferent}`
          });
        }
      }
    });
    return adjusted;
  }
  /**
   * 替换中文代词
   */
  replaceChinesePronouns(translation, referents, adjustments) {
    if (referents.length === 0) return translation;
    let adjusted = translation;
    const primaryReferent = referents[0];
    const pronounReplacements = [
      { pattern: /\bit\b/g, replacement: `the ${primaryReferent}` },
      { pattern: /\bthis\b/g, replacement: `this ${primaryReferent}` },
      { pattern: /\bthat\b/g, replacement: `that ${primaryReferent}` }
    ];
    pronounReplacements.forEach(({ pattern, replacement }) => {
      if (pattern.test(adjusted)) {
        const original = adjusted;
        adjusted = adjusted.replace(pattern, replacement);
        if (original !== adjusted) {
          adjustments.push({
            type: "pronoun",
            original: pattern.toString(),
            adjusted: replacement,
            reason: `Pronoun disambiguation, referent: ${primaryReferent}`
          });
        }
      }
    });
    return adjusted;
  }
  /**
   * 强制术语一致性
   */
  async enforceTerminologyConsistency(context, translation, adjustments) {
    let adjustedTranslation = translation;
    for (const [term, preferredTranslation] of context.globalTerminology.entries()) {
      const variations = this.findTermVariations(term, adjustedTranslation);
      variations.forEach((variation) => {
        if (variation !== preferredTranslation) {
          adjustedTranslation = adjustedTranslation.replace(variation, preferredTranslation);
          adjustments.push({
            type: "terminology",
            original: variation,
            adjusted: preferredTranslation,
            reason: `术语一致性调整，统一使用：${preferredTranslation}`
          });
        }
      });
    }
    return adjustedTranslation;
  }
  /**
   * 查找术语变体
   */
  findTermVariations(term, text) {
    const variations = [];
    const lowerTerm = term.toLowerCase();
    const words = text.split(/\s+/);
    words.forEach((word) => {
      const cleanWord = word.toLowerCase().replace(/[^\w]/g, "");
      if (cleanWord.includes(lowerTerm) || lowerTerm.includes(cleanWord)) {
        if (cleanWord.length > 2) {
          variations.push(word);
        }
      }
    });
    return variations;
  }
  /**
   * 调整语调
   */
  async adjustTone(context, translation, source, target, adjustments) {
    const requiredTone = context.documentTone;
    let adjustedTranslation = translation;
    if (target === "zh") {
      adjustedTranslation = await this.adjustChineseTone(
        translation,
        requiredTone,
        adjustments
      );
    } else if (target === "en") {
      adjustedTranslation = await this.adjustEnglishTone(
        translation,
        requiredTone,
        adjustments
      );
    }
    return adjustedTranslation;
  }
  /**
   * 调整中文语调
   */
  async adjustChineseTone(translation, requiredTone, adjustments) {
    let adjusted = translation;
    switch (requiredTone) {
      case "formal":
        adjusted = adjusted.replace(/\b你\b/g, "您").replace(/\b挺\b/g, "相当").replace(/\b很棒\b/g, "优秀");
        break;
      case "technical":
        adjusted = adjusted.replace(/\b做\b/g, "执行").replace(/\b用\b/g, "使用").replace(/\b好的\b/g, "有效的");
        break;
      case "academic":
        adjusted = adjusted.replace(/\b我们认为\b/g, "本研究认为").replace(/\b发现\b/g, "研究发现").replace(/\b结果\b/g, "研究结果");
        break;
    }
    if (adjusted !== translation) {
      adjustments.push({
        type: "tone",
        original: translation,
        adjusted,
        reason: `语调调整为${requiredTone}风格`
      });
    }
    return adjusted;
  }
  /**
   * 调整英文语调
   */
  async adjustEnglishTone(translation, requiredTone, adjustments) {
    let adjusted = translation;
    switch (requiredTone) {
      case "formal":
        adjusted = adjusted.replace(/\bcan't\b/g, "cannot").replace(/\bwon't\b/g, "will not").replace(/\bget\b/g, "obtain");
        break;
      case "technical":
        adjusted = adjusted.replace(/\bmake\b/g, "create").replace(/\buse\b/g, "utilize").replace(/\bshow\b/g, "demonstrate");
        break;
      case "academic":
        adjusted = adjusted.replace(/\bI think\b/g, "This research suggests").replace(/\bfind\b/g, "observe").replace(/\bresults\b/g, "findings");
        break;
    }
    if (adjusted !== translation) {
      adjustments.push({
        type: "tone",
        original: translation,
        adjusted,
        reason: `Tone adjusted to ${requiredTone} style`
      });
    }
    return adjusted;
  }
  /**
   * 调整时态
   */
  async adjustTense(sentence, context, translation, source, target, adjustments) {
    const temporalRelations = sentence.semanticRelations.filter((r) => r.type === "temporal");
    if (temporalRelations.length === 0) return translation;
    let adjustedTranslation = translation;
    return adjustedTranslation;
  }
  /**
   * 文化适应性调整
   */
  async applyCulturalAdjustments(translation, source, target, domain, adjustments) {
    let adjustedTranslation = translation;
    if (source === "en" && target === "zh") {
      adjustedTranslation = await this.applyChineseCulturalAdjustments(
        translation,
        domain,
        adjustments
      );
    } else if (source === "zh" && target === "en") {
      adjustedTranslation = await this.applyEnglishCulturalAdjustments(
        translation,
        domain,
        adjustments
      );
    }
    return adjustedTranslation;
  }
  /**
   * 中文文化调整
   */
  async applyChineseCulturalAdjustments(translation, domain, adjustments) {
    let adjusted = translation;
    if (domain === "business") {
      adjusted = adjusted.replace(/\bdear\s+([^,]+),/gi, "尊敬的$1：").replace(/\bbest regards\b/gi, "此致敬礼").replace(/\bsincerely\b/gi, "诚挚地");
    }
    if (domain === "academic") {
      adjusted = adjusted.replace(/\bwe believe\b/gi, "我们认为").replace(/\bin conclusion\b/gi, "综上所述").replace(/\bfurthermore\b/gi, "此外");
    }
    if (adjusted !== translation) {
      adjustments.push({
        type: "cultural",
        original: translation,
        adjusted,
        reason: `中文文化适应性调整（${domain}领域）`
      });
    }
    return adjusted;
  }
  /**
   * 英文文化调整
   */
  async applyEnglishCulturalAdjustments(translation, domain, adjustments) {
    let adjusted = translation;
    if (domain === "business") {
      adjusted = adjusted.replace(/\b尊敬的([^：]+)：/g, "Dear $1,").replace(/\b此致敬礼\b/g, "Best regards").replace(/\b诚挚地\b/g, "Sincerely");
    }
    if (domain === "academic") {
      adjusted = adjusted.replace(/\b我们认为\b/g, "We believe that").replace(/\b综上所述\b/g, "In conclusion").replace(/\b此外\b/g, "Furthermore");
    }
    if (adjusted !== translation) {
      adjustments.push({
        type: "cultural",
        original: translation,
        adjusted,
        reason: `English cultural adaptation (${domain} domain)`
      });
    }
    return adjusted;
  }
  /**
   * 计算上下文置信度
   */
  calculateContextualConfidence(sentence, context, adjustments) {
    let confidence = 0.5;
    confidence += sentence.dependencies.length * 0.1;
    confidence += sentence.semanticRelations.length * 0.1;
    confidence += Math.min(adjustments.length * 0.05, 0.2);
    confidence += context.globalTerminology.size > 0 ? 0.1 : 0;
    return Math.min(1, confidence);
  }
  /**
   * 检测文档领域
   */
  async detectDomain(sentences) {
    const allText = sentences.join(" ").toLowerCase();
    const domainKeywords = {
      "tech": ["api", "software", "programming", "algorithm", "database", "computer"],
      "business": ["revenue", "profit", "market", "strategy", "management", "customer"],
      "academic": ["research", "study", "analysis", "theory", "methodology", "hypothesis"],
      "medical": ["patient", "treatment", "diagnosis", "medicine", "therapy", "clinical"],
      "legal": ["contract", "law", "legal", "court", "regulation", "compliance"]
    };
    let maxScore = 0;
    let detectedDomain = "general";
    for (const [domain, keywords] of Object.entries(domainKeywords)) {
      let score = 0;
      keywords.forEach((keyword) => {
        if (allText.includes(keyword)) {
          score++;
        }
      });
      if (score > maxScore) {
        maxScore = score;
        detectedDomain = domain;
      }
    }
    return detectedDomain;
  }
  /**
   * 获取文档上下文
   */
  getDocumentContext(documentId) {
    return this.documentContexts.get(documentId);
  }
  /**
   * 清理过期上下文
   */
  cleanupExpiredContexts(maxAge = 24 * 60 * 60 * 1e3) {
    const cutoffTime = Date.now() - maxAge;
    let cleanedCount = 0;
    for (const [id, context] of this.documentContexts.entries()) {
      if (context.createdAt < cutoffTime) {
        this.documentContexts.delete(id);
        cleanedCount++;
      }
    }
    return cleanedCount;
  }
  /**
   * 获取统计信息
   */
  getStats() {
    return {
      activeContexts: this.documentContexts.size,
      patterns: this.contextPatterns.size,
      initialized: this.initialized
    };
  }
}
class TerminologyExtractor {
  constructor() {
    __publicField(this, "commonWords", /* @__PURE__ */ new Set([
      "the",
      "a",
      "an",
      "and",
      "or",
      "but",
      "in",
      "on",
      "at",
      "to",
      "for",
      "of",
      "with",
      "by",
      "的",
      "是",
      "在",
      "有",
      "和",
      "或",
      "但",
      "与",
      "为",
      "由",
      "从",
      "到"
    ]));
  }
  async initialize() {
  }
  async extractGlobalTerminology(sentences) {
    const terminology = /* @__PURE__ */ new Map();
    const allText = sentences.join(" ");
    const words = allText.split(/\s+/);
    const termFrequency = /* @__PURE__ */ new Map();
    words.forEach((word) => {
      const cleanWord = word.toLowerCase().replace(/[^\w]/g, "");
      if (cleanWord.length > 3 && !this.commonWords.has(cleanWord)) {
        termFrequency.set(cleanWord, (termFrequency.get(cleanWord) || 0) + 1);
      }
    });
    for (const [term, frequency] of termFrequency.entries()) {
      if (frequency >= 3) {
        terminology.set(term, term);
      }
    }
    return terminology;
  }
}
class SemanticAnalyzer {
  async initialize() {
  }
  async analyzeRelations(sentence, allSentences, currentIndex) {
    const relations = [];
    if (currentIndex > 0) {
      allSentences[currentIndex - 1];
      if (/because|since|therefore|thus/.test(sentence.toLowerCase())) {
        relations.push({
          type: "causation",
          targetSentenceId: `sentence_${currentIndex - 1}`,
          confidence: 0.8
        });
      }
      if (/however|but|nevertheless/.test(sentence.toLowerCase())) {
        relations.push({
          type: "contrast",
          targetSentenceId: `sentence_${currentIndex - 1}`,
          confidence: 0.7
        });
      }
      if (/also|additionally|furthermore|moreover/.test(sentence.toLowerCase())) {
        relations.push({
          type: "continuation",
          targetSentenceId: `sentence_${currentIndex - 1}`,
          confidence: 0.6
        });
      }
    }
    return relations;
  }
}
class TonalAnalyzer {
  async initialize() {
  }
  async analyzeTone(text) {
    const lowerText = text.toLowerCase();
    if (/\b(algorithm|api|database|software|programming|code|system|technology)\b/.test(lowerText)) {
      return "technical";
    }
    if (/\b(research|study|methodology|hypothesis|analysis|findings|conclusion|literature)\b/.test(lowerText)) {
      return "academic";
    }
    if (/\b(hereby|whereas|furthermore|nevertheless|consequently|respectively)\b/.test(lowerText)) {
      return "formal";
    }
    if (/\b(imagine|creative|innovative|inspiring|amazing|wonderful|fantastic)\b/.test(lowerText)) {
      return "creative";
    }
    return "informal";
  }
}
const contextualTranslationEngine = new ContextualTranslationEngine();
const __vite_import_meta_env__ = { "BASE_URL": "/", "DEV": false, "MODE": "production", "PROD": true, "SSR": false };
const DEFAULT_CONFIG = {
  reduceMotion: false,
  immersiveModeEnabled: true,
  autoClipboard: false,
  cacheTTL: 3600,
  offlineEnabled: true,
  memoryEnabled: true,
  contextAwareEnabled: true,
  batchProcessingEnabled: true
};
class OptimizedTranslationService {
  constructor() {
    __publicField(this, "initialized", false);
    __publicField(this, "config", DEFAULT_CONFIG);
  }
  /**
   * 初始化服务
   */
  async initialize() {
    if (this.initialized) return;
    try {
      this.config = await this.getConfig();
      if (this.config.offlineEnabled) {
        await offlineTranslationManager.initialize();
        console.log("Offline translation system initialized");
      }
      if (this.config.memoryEnabled) {
        await personalTranslationMemory.initialize();
        console.log("Personal translation memory initialized");
      }
      if (this.config.contextAwareEnabled) {
        await contextualTranslationEngine.initialize();
        console.log("Contextual translation engine initialized");
      }
      this.initialized = true;
      console.log("Optimized Translation Service initialized successfully");
    } catch (error) {
      console.error("Failed to initialize translation service:", error);
      throw error;
    }
  }
  /**
   * 智能翻译处理
   */
  async handleTranslateRequest(request) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }
      if (this.config.memoryEnabled) {
        const memorySuggestion = await personalTranslationMemory.getPersonalizedSuggestion(
          request.text,
          request.source,
          request.target,
          request.context
        );
        if (memorySuggestion.confidence > 0.8) {
          await personalTranslationMemory.addMemory(
            request.text,
            memorySuggestion.suggestion,
            request.source,
            request.target,
            request.context
          );
          return {
            ok: true,
            data: {
              translatedText: memorySuggestion.suggestion,
              confidence: memorySuggestion.confidence,
              source: "memory",
              alternatives: memorySuggestion.alternatives
            }
          };
        }
      }
      if (this.config.contextAwareEnabled && request.documentId && request.sentenceIndex !== void 0) {
        try {
          const contextualResult = await contextualTranslationEngine.translateWithContext(
            request.documentId,
            request.sentenceIndex,
            request.source,
            request.target
          );
          if (contextualResult.confidence > 0.6) {
            return {
              ok: true,
              data: {
                translatedText: contextualResult.translatedText,
                confidence: contextualResult.confidence,
                source: "contextual",
                contextualAdjustments: contextualResult.contextualAdjustments
              }
            };
          }
        } catch (contextError) {
          console.warn("Contextual translation failed:", contextError);
        }
      }
      try {
        const onlineResult = await this.fetchOnlineTranslation(request);
        if (this.config.memoryEnabled && onlineResult.ok && onlineResult.data) {
          await personalTranslationMemory.addMemory(
            request.text,
            onlineResult.data.translatedText,
            request.source,
            request.target,
            request.context
          );
        }
        return onlineResult;
      } catch (onlineError) {
        console.warn("Online translation failed:", onlineError);
        if (this.config.offlineEnabled) {
          try {
            const offlineResult = await offlineTranslationManager.translate(
              request.text,
              request.source,
              request.target
            );
            return {
              ok: true,
              data: {
                translatedText: offlineResult.translated,
                confidence: offlineResult.confidence,
                source: "offline"
              }
            };
          } catch (offlineError) {
            console.warn("Offline translation failed:", offlineError);
          }
        }
        return {
          ok: true,
          data: {
            translatedText: request.text,
            confidence: 0,
            source: "offline"
          }
        };
      }
    } catch (error) {
      console.error("Translation handler error:", error);
      return {
        ok: false,
        error: {
          code: "HANDLER_ERROR",
          message: error.message || "Internal translation error"
        }
      };
    }
  }
  /**
   * 在线翻译（使用请求管理器）
   */
  async fetchOnlineTranslation(request) {
    if (this.config.batchProcessingEnabled) {
      return await requestManager.addRequest({
        id: request.id,
        text: request.text,
        source: request.source,
        target: request.target,
        format: request.format || "text",
        context: request.context,
        priority: request.priority || 1
      });
    } else {
      return await this.directFetchTranslation(request);
    }
  }
  /**
   * 直接翻译请求
   */
  async directFetchTranslation(request) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1e4);
    try {
      const backendUrl = __vite_import_meta_env__?.BACKEND_URL || "http://localhost:8000";
      const response = await fetch(`${backendUrl}/translate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          target: request.target,
          segments: [
            {
              id: request.id,
              text: request.text,
              model: "qwen-turbo-latest"
            }
          ]
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const result = await response.json();
      const segment = result.segments?.find((s) => s.id === request.id);
      if (!segment) {
        throw new Error("无法找到对应的翻译结果");
      }
      return {
        ok: true,
        data: {
          translatedText: segment.text,
          detectedLanguage: result.translated,
          alternatives: [],
          source: "online"
        }
      };
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }
  /**
   * 创建文档上下文
   */
  async createDocumentContext(documentId, sentences, metadata) {
    if (!this.config.contextAwareEnabled) {
      return { ok: false, error: { code: "CONTEXT_DISABLED", message: "Context awareness is disabled" } };
    }
    try {
      const context = await contextualTranslationEngine.createDocumentContext(
        documentId,
        sentences,
        metadata
      );
      return { ok: true, data: context };
    } catch (error) {
      return {
        ok: false,
        error: {
          code: "CONTEXT_CREATION_ERROR",
          message: error.message || "Failed to create document context"
        }
      };
    }
  }
  /**
   * 图片翻译
   */
  async translateImage(fileData, fileName, fileType) {
    try {
      console.log("Translating image:", fileName, fileType);
      await new Promise((resolve) => setTimeout(resolve, 2e3));
      return {
        ok: true,
        data: {
          translatedText: `这是从图片 "${fileName}" 中识别并翻译的文本内容。

OCR识别和翻译功能需要连接到后端服务来实现。`,
          detectedLanguage: "en",
          alternatives: [],
          source: "offline"
        }
      };
    } catch (error) {
      return {
        ok: false,
        error: {
          code: "IMAGE_TRANSLATION_ERROR",
          message: error.message || "图片翻译失败"
        }
      };
    }
  }
  /**
   * 文档翻译
   */
  async translateDocument(fileData, fileName, fileType) {
    try {
      console.log("Translating document:", fileName, fileType);
      await new Promise((resolve) => setTimeout(resolve, 2e3));
      return {
        ok: true,
        data: {
          translatedText: `这是从文档 "${fileName}" 中提取并翻译的文本内容。

文档解析和翻译功能需要连接到后端服务来实现。`,
          detectedLanguage: "en",
          alternatives: [],
          source: "offline"
        }
      };
    } catch (error) {
      return {
        ok: false,
        error: {
          code: "DOCUMENT_TRANSLATION_ERROR",
          message: error.message || "文档翻译失败"
        }
      };
    }
  }
  /**
   * 获取统计信息
   */
  async getStats() {
    const stats = {
      initialized: this.initialized,
      config: this.config,
      requestManager: requestManager.getStats(),
      offlineTranslation: this.config.offlineEnabled ? offlineTranslationManager.getStats() : null,
      personalMemory: this.config.memoryEnabled ? await personalTranslationMemory.getStats() : null,
      contextualEngine: this.config.contextAwareEnabled ? contextualTranslationEngine.getStats() : null
    };
    return { ok: true, data: stats };
  }
  /**
   * 获取配置
   */
  async getConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get(DEFAULT_CONFIG, (result) => {
        resolve({ ...DEFAULT_CONFIG, ...result });
      });
    });
  }
  /**
   * 清理缓存
   */
  async clearCache() {
    try {
      if (this.config.memoryEnabled) {
        await personalTranslationMemory.cleanupExpiredMemories();
      }
      if (this.config.contextAwareEnabled) {
        contextualTranslationEngine.cleanupExpiredContexts();
      }
      console.log("Cache cleanup completed");
    } catch (error) {
      console.warn("Cache cleanup failed:", error);
    }
  }
}
const translationService = new OptimizedTranslationService();
async function handleMessage(message, sender, sendResponse) {
  console.log("Service worker received message:", message.type, sender.tab?.id);
  try {
    switch (message.type) {
      case "translate":
        const translateResult = await translationService.handleTranslateRequest(message.payload);
        sendResponse(translateResult);
        break;
      case "translateImage":
        const imageTranslateResult = await translationService.translateImage(
          message.payload.file,
          message.payload.fileName,
          message.payload.fileType
        );
        sendResponse(imageTranslateResult);
        break;
      case "translateDocument":
        const documentTranslateResult = await translationService.translateDocument(
          message.payload.file,
          message.payload.fileName,
          message.payload.fileType
        );
        sendResponse(documentTranslateResult);
        break;
      case "createContext":
        const contextResult = await translationService.createDocumentContext(
          message.payload.documentId,
          message.payload.sentences,
          message.payload.metadata
        );
        sendResponse(contextResult);
        break;
      case "languages":
        sendResponse({
          ok: true,
          data: {
            languages: [
              { code: "en", name: "English" },
              { code: "zh", name: "中文" },
              { code: "ja", name: "日本語" },
              { code: "ko", name: "한국어" },
              { code: "fr", name: "Français" },
              { code: "de", name: "Deutsch" },
              { code: "es", name: "Español" },
              { code: "pt", name: "Português" },
              { code: "ru", name: "Русский" },
              { code: "ar", name: "العربية" }
            ]
          }
        });
        break;
      case "detect":
        try {
          const detectedLang = await offlineTranslationManager.detectLanguage(message.payload.text);
          sendResponse({
            ok: true,
            data: { detectedLanguage: detectedLang }
          });
        } catch (error) {
          sendResponse({
            ok: false,
            error: {
              code: "DETECTION_ERROR",
              message: "Language detection failed"
            }
          });
        }
        break;
      case "clearCache":
        await translationService.clearCache();
        sendResponse({ ok: true });
        break;
      case "getStats":
        const statsResult = await translationService.getStats();
        sendResponse(statsResult);
        break;
      default:
        sendResponse({
          ok: false,
          error: {
            code: "UNKNOWN_MESSAGE_TYPE",
            message: `Unknown message type: ${message.type}`
          }
        });
    }
  } catch (error) {
    console.error("Message handler error:", error);
    sendResponse({
      ok: false,
      error: {
        code: "MESSAGE_HANDLER_ERROR",
        message: error.message || "Internal message handler error"
      }
    });
  }
}
async function setupContextMenus() {
  try {
    await chrome.contextMenus.removeAll();
    chrome.contextMenus.create({
      id: "translateSelection",
      title: "翻译选中文本",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "translateImage",
      title: "翻译图片",
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "immersiveTranslate",
      title: "沉浸式翻译",
      contexts: ["page"]
    });
    console.log("Context menus created successfully");
  } catch (error) {
    console.error("Failed to setup context menus:", error);
  }
}
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenus();
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender, sendResponse);
  return true;
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  console.log("Context menu clicked:", info.menuItemId, tab?.id);
  if (info.menuItemId === "translateSelection" && info.selectionText) {
    chrome.tabs.sendMessage(tab.id, {
      type: "translateSelection",
      text: info.selectionText
    });
  } else if (info.menuItemId === "translateImage" && info.srcUrl) {
    console.log("Translate image:", info.srcUrl);
  } else if (info.menuItemId === "immersiveTranslate") {
    chrome.tabs.sendMessage(tab.id, {
      type: "toggleImmersiveTranslation"
    });
  }
});
chrome.commands.onCommand.addListener((command, tab) => {
  console.log("Command triggered:", command, tab?.id);
  if (command === "toggle-immersive" && tab?.id) {
    chrome.tabs.sendMessage(tab.id, {
      type: "toggleImmersiveTranslation"
    });
  }
});
setInterval(async () => {
  try {
    await translationService.clearCache();
  } catch (error) {
    console.warn("Scheduled cleanup failed:", error);
  }
}, 60 * 60 * 1e3);
console.log("Optimized Service Worker loaded successfully");
//# sourceMappingURL=serviceWorker.js.map
